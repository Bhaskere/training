
function callDate()
{
  document.getElementById('demo').innerHTML = Date();
}